package sample;

public class Paciente {
    private String sexo;
    private int edad;
    private double peso;
    private int altura;
    private double actividadFisica;
    private int caloriasDiarias;

    public Paciente() {
    }

    public Paciente(String sexo, int edad, double peso, int altura, double actividadFisica) {
        this.sexo = sexo;
        this.edad = edad;
        this.peso = peso;
        this.altura = altura;
        this.actividadFisica = actividadFisica;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public double getActividadFisica() {
        return actividadFisica;
    }

    public void setActividadFisica(double actividadFisica) {
        this.actividadFisica = actividadFisica;
    }

    public int getCaloriasDiarias() {
        return caloriasDiarias;
    }

    public void setCaloriasDiarias(int caloriasDiarias) {
        this.caloriasDiarias = caloriasDiarias;
    }
}
