package sample;

public class Validaciones {

    public int validarAltura(int altura) {
        String alturaRegex = String.valueOf(altura);
        if (alturaRegex.matches("[\\d]{1,3}")) {
            if (altura >= 20 && altura <= 250){
                return 1;
            }
        } else {
            return -1;
        }
       return 0;
    }

    public int validarEdad (int edad) {
        String edadRegex = String.valueOf(edad);
        if (edadRegex.matches("[\\d]{1,3}")) {
            if (edad >= 0 && edad <= 120) {
                return 1;
            }
        } else {
            return -1;
        }
        return 0;
    }

    public int validarPeso (double peso) {
        String pesoRegex = String.valueOf(peso);
        if (pesoRegex.matches("^[0-9]+(\\.[0-9]{1,2})?$")) {
            if (peso >= 0.25 && peso <= 600) {
                return 1;
            }
        } else {
            return -1;
        }
        return 0;
    }
}
