package sample;

import javafx.fxml.FXML;
import javafx.scene.control.*;

public class Controller {

    @FXML
    private ComboBox sexoCombo;
    @FXML
    private TextField edadText;
    @FXML
    private TextField estaturaText;
    @FXML
    private TextField kilosText;
    @FXML
    private RadioButton pocaActividadButton;
    @FXML
    private RadioButton ejercicioLigeroButton;
    @FXML
    private RadioButton ejercicioModeradoButton;
    @FXML
    private RadioButton deporteRegularButton;
    @FXML
    private RadioButton deportistaEliteButton;
    @FXML
    private TextField caloriasPorDiaText;

    private Paciente paciente;
    private double actividadFisica = 0;
    Validaciones validaciones = new Validaciones();

    public Controller(){}

    public void mostrarAlerta(String variableError, String textoError) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Datos incorrectos en campo " + variableError);
        alert.setContentText(textoError);
        alert.showAndWait();
    }

    public void pocaActividad() {
        actividadFisica = 1.2;
    }

    public void ejercicioLigero() {
        actividadFisica = 1.375;
    }

    public void ejercicioModerado() {
        actividadFisica = 1.55;
    }

    public void deporteRegular() {
        actividadFisica = 1.725;
    }

    public void deportistaElite() {
        actividadFisica = 1.9;
    }

    public boolean extraerDatos () {
        String sexo = (String) sexoCombo.getSelectionModel().getSelectedItem();
        if (sexo == null) {
            mostrarAlerta("Sexo", "Selecciona una opción de la lista.");
            return false;
        }
        if (edadText.getText() != "") {
            if (validaciones.validarEdad(Integer.valueOf(edadText.getText())) == -1) {
                mostrarAlerta("Edad", "Datos inválidos o fuera de rango.");
                return false;
            } else if (validaciones.validarEdad(Integer.valueOf(edadText.getText())) == 0) {
                mostrarAlerta("Edad", "Introduzca un valor entre 0 y 120.");
                return false;
            }
        } else {
            mostrarAlerta("Edad", "No puede dejar campos vacíos.");
            return false;
        }
        if (estaturaText.getText() != "") {
            if (validaciones.validarAltura(Integer.valueOf(estaturaText.getText())) == -1) {
                mostrarAlerta("Estatura", "Datos inválidos o fuera de rango.");
                return false;
            } else if (validaciones.validarAltura(Integer.valueOf(estaturaText.getText())) == 0) {
                mostrarAlerta("Estatura", "Introduzca un valor entre 20 y 250.");
                return false;
            }
        } else {
            mostrarAlerta("Estatura", "No puede dejar campos vacíos.");
            return false;
        }
        if (kilosText.getText() != "") {
            if (validaciones.validarPeso(Double.valueOf(kilosText.getText())) == -1) {
                mostrarAlerta("Peso", "Datos inválidos o fuera de rango (máx. 2 decimales después del punto).");
                return false;
            } else if (validaciones.validarPeso(Double.valueOf(kilosText.getText())) == 0) {
                mostrarAlerta("Peso", "Introduzca un valor entre 0.25 y 600.");
                return false;
            }
        } else {
            mostrarAlerta("Peso", "No puede dejar campos vacíos.");
            return false;
        }
        if (actividadFisica == 0) {
            mostrarAlerta("Actividad Fisica", "Selecciona un tipo de actividad física.");
            return false;
        }
        return true;
    }

    public boolean crearPaciente() {
        if (extraerDatos())  {
            String sexo = (String) sexoCombo.getSelectionModel().getSelectedItem();
            int edad = Integer.valueOf(edadText.getText());
            double peso = Double.valueOf(kilosText.getText());
            int estatura = Integer.valueOf(estaturaText.getText());
            paciente = new Paciente(sexo, edad, peso, estatura, actividadFisica);
            return true;
        }
        return false;
    }

    public void calcularCalorias() {
        int calorias = 0;
        if (paciente.getSexo().equals("Masculino")) {
            calorias = (int) Math.round(((10 * paciente.getPeso())
                    + (6.25 * paciente.getAltura()) - (5 * paciente.getEdad()) + 5));
        } else if (paciente.getSexo().equals("Femenino")) {
            calorias = (int) Math.round(((10 * paciente.getPeso())
                    + (6.25 * paciente.getAltura()) - (5 * paciente.getEdad()) - 161));
        }
        calorias = (int) Math.round(calorias * actividadFisica);
        paciente.setCaloriasDiarias(calorias);
    }

    public void mostrarCaloriasResultantes() {
        if (crearPaciente()) {
            calcularCalorias();
            caloriasPorDiaText.setText(String.valueOf(paciente.getCaloriasDiarias()));
        }
    }







}
